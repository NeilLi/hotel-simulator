import React, { useState, useEffect, useRef } from 'react';
import { Agent } from '../types';
import { geminiService } from '../services/geminiService';
import { Mic, Send, X, Bot, Activity, Wifi } from 'lucide-react';

interface AgentChatInterfaceProps {
  agent: Agent;
  onClose: () => void;
}

interface Message {
  role: 'user' | 'model';
  text: string;
}

export const AgentChatInterface: React.FC<AgentChatInterfaceProps> = ({ agent, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: `Greetings. I am ${agent.role.replace('ROBOT_', '')} Unit ${agent.id}. How may I assist you today?` }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const sendMessage = async (text: string) => {
    if (!text.trim()) return;
    
    // Add User Message
    const newHistory = [...messages, { role: 'user', text: text } as Message];
    setMessages(newHistory);
    setInput("");
    setIsLoading(true);

    try {
        // Convert local message format to API format
        const apiHistory = messages.map(m => ({ 
            role: m.role, 
            parts: [{ text: m.text }] 
        }));

        const responseText = await geminiService.stepAgentChat(agent.role, apiHistory, text);
        
        setMessages(prev => [...prev, { role: 'model', text: responseText }]);
    } catch (e) {
        console.error(e);
    } finally {
        setIsLoading(false);
    }
  };

  const startListening = () => {
    if (!('webkitSpeechRecognition' in window)) {
        alert("Speech recognition is not supported in this browser. Please use Chrome.");
        return;
    }

    const SpeechRecognition = (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
            sendMessage(transcript);
        }
    };
    recognition.start();
  };

  return (
    <div className="absolute bottom-24 left-1/2 -translate-x-1/2 w-[450px] bg-slate-900/90 backdrop-blur-xl border border-cyan-500/30 rounded-2xl overflow-hidden shadow-[0_0_50px_rgba(0,0,0,0.8)] z-50 animate-in slide-in-from-bottom-10 fade-in duration-500 flex flex-col">
       
       {/* Header */}
       <div className="p-4 bg-slate-950/50 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-3">
             <div className="p-2 bg-cyan-500/10 rounded-lg border border-cyan-500/20">
                <Bot size={18} className="text-cyan-400" />
             </div>
             <div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">{agent.role.replace('ROBOT_', '')}</h3>
                <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span className="text-[9px] font-mono text-cyan-500/60 uppercase tracking-widest">Connected • ID: {agent.id}</span>
                </div>
             </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full text-slate-500 hover:text-white transition-colors">
            <X size={16} />
          </button>
       </div>

       {/* Chat Area */}
       <div ref={scrollRef} className="h-64 overflow-y-auto p-4 space-y-4 bg-black/20">
          {messages.map((m, i) => (
             <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`
                   max-w-[80%] p-3 rounded-2xl text-[11px] leading-relaxed
                   ${m.role === 'user' 
                     ? 'bg-cyan-600/20 border border-cyan-500/30 text-cyan-50 rounded-tr-sm' 
                     : 'bg-slate-800 border border-white/5 text-slate-200 rounded-tl-sm'}
                `}>
                   {m.text}
                </div>
             </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
               <div className="flex items-center gap-1 p-3 bg-slate-800/50 rounded-2xl rounded-tl-sm">
                  <div className="w-1.5 h-1.5 bg-cyan-500/50 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-1.5 h-1.5 bg-cyan-500/50 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-1.5 h-1.5 bg-cyan-500/50 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
               </div>
            </div>
          )}
       </div>

       {/* Input Area */}
       <div className="p-4 bg-slate-950/50 border-t border-white/5 flex items-center gap-2">
           <button 
             onClick={startListening}
             className={`p-3 rounded-xl transition-all ${isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-slate-800 text-cyan-400 hover:bg-slate-700'}`}
           >
             <Mic size={18} />
           </button>
           
           <input 
             value={input}
             onChange={(e) => setInput(e.target.value)}
             onKeyDown={(e) => e.key === 'Enter' && sendMessage(input)}
             placeholder={isListening ? "Listening..." : "Type or speak to interact..."}
             className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500/50 focus:bg-slate-800 transition-all placeholder:text-slate-600"
             autoFocus
           />

           <button 
             onClick={() => sendMessage(input)}
             disabled={!input.trim()}
             className="p-3 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/20 rounded-xl disabled:opacity-30 transition-all"
           >
              <Send size={16} />
           </button>
       </div>
    </div>
  );
};