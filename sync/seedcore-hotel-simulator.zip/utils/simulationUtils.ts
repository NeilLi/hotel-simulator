
import { Room, Agent, AgentRole, EntityType, Coordinates } from "../types";
import { GRID_WIDTH, GRID_HEIGHT } from "../constants";

// --- GLOBAL LAYOUT CONSTANTS (Shared for generation and logic) ---
const ATRIUM_W = 20;
const ATRIUM_H = 12;
const ATRIUM_X = Math.floor(GRID_WIDTH / 2) - Math.floor(ATRIUM_W / 2); // 30
const ATRIUM_Y = GRID_HEIGHT - ATRIUM_H - 4; // 28

// Semantic Zones for AI Logic
const ZONES = {
  LOBBY: { x: ATRIUM_X, y: ATRIUM_Y, w: ATRIUM_W, h: ATRIUM_H },
  RECEPTION: { x: ATRIUM_X + Math.floor(ATRIUM_W / 2), y: ATRIUM_Y + 2 },
};

// Define explicitly what agents can walk on
const WALKABLE = new Set([
  EntityType.LOBBY_FLOOR,
  EntityType.ROOM_FLOOR,
  EntityType.GARDEN_PATH,
  EntityType.ROOM_DOOR,
  EntityType.RECEPTION_DESK, // Staff can be behind/at desk
  EntityType.SERVICE_HUB
]);

const isWalkable = (grid: EntityType[][], x: number, y: number) => {
    if (y < 0 || y >= GRID_HEIGHT || x < 0 || x >= GRID_WIDTH) return false;
    return WALKABLE.has(grid[y][x]);
};

export const generateMap = (width: number, height: number) => {
  const grid: EntityType[][] = Array(height).fill(null).map(() => Array(width).fill(EntityType.EMPTY));
  const rooms: Room[] = [];

  const safeSet = (x: number, y: number, type: EntityType) => {
    if (x >= 0 && x < width && y >= 0 && y < height) {
      grid[y][x] = type;
    }
  };

  // 1. GRAND ATRIUM (Lobby)
  for (let y = ATRIUM_Y; y < ATRIUM_Y + ATRIUM_H; y++) {
    for (let x = ATRIUM_X; x < ATRIUM_X + ATRIUM_W; x++) {
      safeSet(x, y, EntityType.LOBBY_FLOOR);
    }
  }
  // Reception Desk
  const deskY = ZONES.RECEPTION.y;
  const deskX = ZONES.RECEPTION.x;
  safeSet(deskX, deskY, EntityType.RECEPTION_DESK);
  safeSet(deskX - 1, deskY, EntityType.RECEPTION_DESK);
  safeSet(deskX + 1, deskY, EntityType.RECEPTION_DESK);

  rooms.push({
    id: "LOBBY-MAIN",
    name: "Grand Atrium",
    type: 'LOBBY',
    topLeft: { x: ATRIUM_X, y: ATRIUM_Y },
    bottomRight: { x: ATRIUM_X + ATRIUM_W - 1, y: ATRIUM_Y + ATRIUM_H - 1 }
  });

  // 2. WINGS GENERATION
  const createRoom = (id: string, x: number, y: number, w: number, h: number) => {
    // Walls
    for (let ry = y; ry < y + h; ry++) {
      for (let rx = x; rx < x + w; rx++) {
        if (rx === x || rx === x + w - 1 || ry === y || ry === y + h - 1) {
           // Door logic: Bottom center of room if above hall, Top center if below
           const isDoor = (ry === y + h - 1 || ry === y) && rx === x + Math.floor(w/2);
           if (isDoor) safeSet(rx, ry, EntityType.ROOM_DOOR);
           else safeSet(rx, ry, EntityType.ROOM_WALL);
        } else {
           safeSet(rx, ry, EntityType.ROOM_FLOOR);
        }
      }
    }
    // Furniture
    safeSet(x + 1, y + 1, EntityType.ROOM_FURNITURE);
    rooms.push({ id, name: `Room ${id}`, type: 'SUITE', topLeft: {x,y}, bottomRight: {x:x+w-1, y:y+h-1} });
  };

  // Vertical Wings extending UP from the Atrium sides
  const westWingX = ATRIUM_X - 2; // 28
  const eastWingX = ATRIUM_X + ATRIUM_W + 1; // 51
  const wingHeight = 26; 
  
  // West Wing Hallway
  for(let y = ATRIUM_Y - wingHeight; y < ATRIUM_Y; y++) {
      safeSet(westWingX, y, EntityType.LOBBY_FLOOR); 
      safeSet(westWingX - 1, y, EntityType.LOBBY_FLOOR); 
  }

  // East Wing Hallway
  for(let y = ATRIUM_Y - wingHeight; y < ATRIUM_Y; y++) {
      safeSet(eastWingX, y, EntityType.LOBBY_FLOOR); 
      safeSet(eastWingX + 1, y, EntityType.LOBBY_FLOOR); 
  }

  // Generate Rooms along West Wing
  for(let i=0; i<6; i++) {
     createRoom(`1${i}A`, westWingX - 6, ATRIUM_Y - 4 - (i*4), 5, 4);
     createRoom(`1${i}B`, westWingX + 1, ATRIUM_Y - 4 - (i*4), 5, 4);
  }

  // Generate Rooms along East Wing
  for(let i=0; i<6; i++) {
     createRoom(`2${i}A`, eastWingX - 5, ATRIUM_Y - 4 - (i*4), 5, 4);
     createRoom(`2${i}B`, eastWingX + 2, ATRIUM_Y - 4 - (i*4), 5, 4);
  }

  // 3. TOP CONNECTING CORRIDOR
  const bridgeY = Math.max(0, ATRIUM_Y - wingHeight);
  for(let x = westWingX; x <= eastWingX; x++) {
      safeSet(x, bridgeY, EntityType.LOBBY_FLOOR);
      safeSet(x, bridgeY + 1, EntityType.LOBBY_FLOOR);
  }
  // Rooms along the top bridge
  for(let i=0; i<6; i++) {
     createRoom(`30${i}`, westWingX + 2 + (i*6), bridgeY - 4, 5, 4);
  }

  // 4. GARDEN
  const gardenX = westWingX + 4;
  const gardenY = bridgeY + 4;
  const gardenW = (eastWingX - westWingX) - 6;
  const gardenH = (ATRIUM_Y - bridgeY) - 6;

  for(let y=gardenY; y<gardenY+gardenH; y++) {
    for(let x=gardenX; x<gardenX+gardenW; x++) {
       const r = Math.random();
       if (r > 0.8) safeSet(x, y, EntityType.GARDEN_PLANT);
       else if (r > 0.6) safeSet(x, y, EntityType.GARDEN_WATER);
       else safeSet(x, y, EntityType.GARDEN_PATH);
    }
  }
  rooms.push({
      id: "GARDEN-MAIN", name: "Central Zen Court", type: 'GARDEN', 
      topLeft: {x: gardenX, y: gardenY}, bottomRight: {x: gardenX+gardenW, y: gardenY+gardenH}
  });

  return { grid, rooms };
};

export const generateAgents = (count: number, width: number, height: number): Agent[] => {
  const agents: Agent[] = [];
  
  // GUEST GENERATION: Focused in the Lobby Atrium for visibility
  const guestCount = 10;
  
  for (let i = 0; i < guestCount; i++) {
    // Spawn mostly in lobby, some near wings
    // Bias towards the center (ATRIUM_X + W/2) ~ 40
    const centerX = ATRIUM_X + Math.floor(ATRIUM_W / 2);
    const centerY = ATRIUM_Y + Math.floor(ATRIUM_H / 2);
    
    // Random position within Atrium bounds
    const spawnX = centerX + Math.floor(Math.random() * 12) - 6;
    const spawnY = centerY + Math.floor(Math.random() * 8) - 4;

    agents.push({
      id: `G-${i}`,
      role: AgentRole.GUEST,
      position: { x: Math.max(0, spawnX), y: Math.max(0, spawnY) },
      target: null, 
      state: 'WALKING',
      mood: 'Neutral'
    });
  }

  // ROBOT GENERATION
  const robotCount = 5;
  
  for (let i = 0; i < robotCount; i++) {
    const isConcierge = i % 2 === 0;
    let spawnX, spawnY;

    if (isConcierge) {
      spawnX = ZONES.RECEPTION.x;
      spawnY = ZONES.RECEPTION.y;
    } else {
      const centerX = ATRIUM_X + Math.floor(ATRIUM_W / 2);
      const centerY = ATRIUM_Y + Math.floor(ATRIUM_H / 2);
      spawnX = centerX + Math.floor(Math.random() * 8) - 4;
      spawnY = centerY + Math.floor(Math.random() * 8) - 4;
    }

    agents.push({
      id: `R-${i}`,
      role: isConcierge ? AgentRole.ROBOT_CONCIERGE : AgentRole.ROBOT_WAITER,
      position: { x: spawnX, y: spawnY },
      target: null,
      state: 'SERVICING',
      mood: 'Operational'
    });
  }

  return agents;
};

export const updateAgentsLogic = (agents: Agent[], grid: EntityType[][]): Agent[] => {
  return agents.map(agent => {
    let { position, target, state } = agent;
    const previousPosition = { ...position };

    const isValid = (x: number, y: number) => isWalkable(grid, x, y);

    // TARGET SELECTION LOGIC
    if (!target || (position.x === target.x && position.y === target.y)) {
       let attempts = 0;
       let found = false;
       
       if (Math.random() > 0.8) {
           return { ...agent, state: 'PAUSING', target: position }; 
       }

       state = 'WALKING';

       while(!found && attempts < 15) {
          let tx, ty;

          // Free movement logic primarily in lobby
          if (agent.role === AgentRole.ROBOT_CONCIERGE) {
             tx = ZONES.RECEPTION.x + Math.floor(Math.random() * 8) - 4;
             ty = ZONES.RECEPTION.y + Math.floor(Math.random() * 6) - 3;
          } 
          else {
             // Guests and Waiters wander the main atrium freely
             const centerX = ATRIUM_X + Math.floor(ATRIUM_W / 2);
             const centerY = ATRIUM_Y + Math.floor(ATRIUM_H / 2);
             
             tx = centerX + Math.floor(Math.random() * 16) - 8;
             ty = centerY + Math.floor(Math.random() * 10) - 5;
          }
          
          tx = Math.floor(tx);
          ty = Math.floor(ty);

          if (isValid(tx, ty)) {
              target = { x: tx, y: ty };
              found = true;
          }
          attempts++;
       }
       
       if (!found) target = position;
    }

    // MOVEMENT LOGIC
    if (target && (target.x !== position.x || target.y !== position.y)) {
       const dx = Math.sign(target.x - position.x);
       const dy = Math.sign(target.y - position.y);
       
       const moves = [];
       if (dx !== 0) moves.push({ x: position.x + dx, y: position.y });
       if (dy !== 0) moves.push({ x: position.x, y: position.y + dy });
       if (dx !== 0 && dy !== 0) moves.push({ x: position.x + dx, y: position.y + dy }); // Allow diagonal

       const validMoves = moves.filter(m => isValid(m.x, m.y));

       if (validMoves.length > 0) {
           position = validMoves[Math.floor(Math.random() * validMoves.length)];
       } else {
           target = null;
       }
    }

    return { ...agent, position, previousPosition, target, state };
  });
};
